using UnityEngine;
using UnityEngine.SceneManagement;   

public class BackButton : MonoBehaviour
{
    public void Backbutton()
    {
        SceneManager.LoadScene("Main Menu");
    }
}
