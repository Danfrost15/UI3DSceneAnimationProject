using UnityEngine;
using UnityEngine.EventSystems;

public class UIanimator : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
{
    [SerializeField] private Animator animator;

    private static readonly int PopTrigger = Animator.StringToHash("Pop");
    private static readonly int NormTrigger = Animator.StringToHash("Norm");

    private void Reset()
    {
        if (animator == null)
            animator = GetComponent<Animator>();
    }

    // Called when the mouse pointer enters the UI element (hover)
    public void OnPointerEnter(PointerEventData eventData)
    {
#if !UNITY_ANDROID && !UNITY_IOS
        PlayPop();
#endif
    }

    // Called when the mouse pointer exits the UI element
    public void OnPointerExit(PointerEventData eventData)
    {
#if !UNITY_ANDROID && !UNITY_IOS
        PlayNorm();
#endif
    }

    // Called when the UI element is clicked/tapped
    public void OnPointerClick(PointerEventData eventData)
    {
#if UNITY_ANDROID || UNITY_IOS
        PlayPop();
#endif
    }

    /// <summary>
    /// Triggers the "pop" animation.
    /// </summary>
    public void PlayPop()
    {
        if (animator != null)
            animator.SetTrigger("Pop");
    }

    /// <summary>
    /// Triggers the "norm" animation.
    /// </summary>
    public void PlayNorm()
    {
        if (animator != null)
            animator.SetTrigger("Norm");
    }
}