using UnityEngine;

public class Rotstion : MonoBehaviour
{
    public Animator Rotter;
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            Rotter.SetTrigger("Rotate");
        }
        else if (Input.touchCount == 1) {
            Rotter.SetTrigger("Rotate");
        }
    }
}
