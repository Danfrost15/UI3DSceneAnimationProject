using UnityEngine;
using UnityEngine.SceneManagement;

public class Mainmenu : MonoBehaviour
{
    [Header("Transition Animation")]
    [SerializeField] private GameObject transitionImageObject;
    [SerializeField] private Animator transitionAnimator;
    [SerializeField] private string transitionTrigger = "FadeOut";

    [Header("Scene Names")]
    [SerializeField] private string gameSceneName = "CampScene";
    [SerializeField] private string instructionsSceneName = "Instructions";
    [SerializeField] private string creditsSceneName = "Credits";

    [Header("Transition Settings")]
    [SerializeField] private float transitionDuration = 1.0f; // Set to your animation's length

    public void PlayGame()
    {
        StartCoroutine(PlayTransitionAndLoadScene(gameSceneName));
    }

    public void Instructions()
    {
        SceneManager.LoadScene("Instructions");
    }

    public void Credits()
    {
        SceneManager.LoadScene("Credits");
    }

    private System.Collections.IEnumerator PlayTransitionAndLoadScene(string sceneName)
    {
        if (transitionImageObject != null && transitionAnimator != null)
        {
            transitionImageObject.SetActive(true);
            transitionAnimator.SetTrigger("Fade");
            yield return new WaitForSeconds(transitionDuration);
        }
        SceneManager.LoadScene(sceneName);
    }
}